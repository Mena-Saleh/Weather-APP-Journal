/* Global Variables */
const baseURL = "https://api.openweathermap.org/data/2.5/weather?zip=";
const Key = 'd5cc5e55bf802ad20270b080b9bf4af7&units=imperial';
const generateButton = document.getElementById('generate');


// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

// Function to get temperature from the API.
// (It'd be better to do the API call on the server side, as doing it here exposes the key to the users... but for the sake of this project it can be done here for now)
const getAPIData = async (baseURL , zipCode, Key) =>
{

  const res = await fetch(baseURL+zipCode+"&appid="+Key); // Fetch the temperature from the API with a query. (the country is US by default)

  try
  {
    const data = await res.json(); // Store the retrieved Data.
    return data;
    //console.log(data);
  }
  catch (error) // Error handling.
  {
    console.log("error", error);
  }

}
 // Function to post data to the server.
const postData = async ( url = '', data = {})=>{
      const res = await fetch(url, {
      method: 'POST',  // Method of type "Post"
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify(data), // Body data type must match "Content-Type" header
    });

      try {
        const newData = await res.json();
        return newData;
      }
      catch(error) {
      console.log("error", error);  // Error handling

      }
  }

 // Function to update GUI
 const updateGUI = async () => {
    const req = await fetch('/all'); // Fetch data stored in our web server through the get route.
    try
    {
      const data = await req.json(); // Store the fetched data in json format.
      // Date conversion
      const date = new Date(data.date *1000); // Date in milliseconds (from unix to milliseconds)
      const humanDateFormat = date.toLocaleString(); // Date in MM/DD/YYYY + Time format.
      // Updating UI elements:
      document.querySelector("#date").innerText = humanDateFormat;
      document.querySelector("#temp").innerText = data.temperature + "°F";
      document.querySelector("#content").innerText = data.userResponse;


    }
    catch (error) // Error handling
    {
      console.log("error", error);
    }

 }


 // Event listener for the button with id generate.
generateButton.addEventListener('click', () =>{

 let zipCode = document.getElementById('zip').value; // Get zip code from the user.
 let userInput = document.getElementById('feelings').value; // Get user response.

  getAPIData(baseURL, zipCode, Key) // API call
  .then(function(data){
  //console.log(data);
  postData('/addData', {temperature: data.main.temp, date: data.dt , userResponse: userInput}) // Send data to server.
  }).then(setTimeout(updateGUI, 300)); 

  //Note: for some reason this code makes it send data from the server before recieving it, so I used setTimeout as a work around for now...
  //If you remove setTimeout, you'll find that on clicked you get the data from the prior entry not the current one which is a major bug.

// Get data from server and update GUI with it.

});


//ERROR: it adds the stuff to the ui before updating, meaning it adds the last entry....

//more info about error: somehow the server sends the data object before recieving it? so it sends the last instance but why...
